.Folio One Page - Created by Michele Cialone - 2013/theuncreativelab.com

.Folio .psd theme is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these elements anywhere you want, however well highly appreciate if you will link to our website when you share them - http://theuncreativelab.com

Thanks for supporting our website and enjoy!

Links:
http://theuncreativelab.com
http://2ndself.com



.Folio .psd theme is made using the Bebas Neue typeface, which can be downloaded for free here: http://www.fontsquirrel.com/fonts/bebas-neue

Image Credit: 
http://www.sxc.hu/
http://unsplash.com/